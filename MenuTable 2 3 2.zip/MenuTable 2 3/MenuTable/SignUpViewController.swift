//
//  SignUpViewController.swift
//  MenuTable
//
//  Created by user243826 on 7/30/23.
//

import UIKit

class SignUpViewController: UIViewController
{
    
    @IBOutlet weak var txtName: UITextField!

    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSignUp(_ sender: Any)
    {
        //let tableVC:TableViewController = self.storyboard?.instantiateViewController(withIdentifier: "TableViewController") as! TableViewController
        let tableVC = self.storyboard?.instantiateViewController(withIdentifier: "TableViewController")
        
        self.navigationController?.pushViewController(tableVC!, animated: true)
   
    }
    
    @IBAction func btnSignIn(_ sender: Any)
    {
        let tableVC:SignInViewController = self.storyboard?.instantiateViewController(withIdentifier: "SignInViewController") as! SignInViewController
        
        
        
        self.navigationController?.pushViewController(tableVC, animated: true)
   
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
