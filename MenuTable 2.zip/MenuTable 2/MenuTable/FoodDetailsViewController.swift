//
//  FoodDetailsViewController.swift
//  MenuTable
//
//  Created by Ravneesh Singh Matharu on 2023-07-29.
//

import UIKit
import CoreData

class FoodDetailsViewController: UIViewController {
    
    
    @IBOutlet weak var foodImage: UIImageView!
    @IBOutlet weak var foodName: UILabel!
    @IBOutlet weak var foodDesciption: UILabel!
    @IBOutlet weak var foodQuantity: UILabel!
    @IBOutlet weak var foodPrice: UILabel!
    
    var name:String = ""
    var priceVal:String!
    var image:UIImage!
    var foodDesc:String!
    var foodQty:String!
    //var quantity: Int!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        foodImage.image = image
        foodName.text = name
        foodDesciption.text = foodDesc
        foodQuantity.text = foodQty
        quantity = Int(foodQty)!
        
//        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//
//        let query = NSFetchRequest<NSFetchRequestResult>(entityName: "Details");
//
//        do {
//                  let result = try context.fetch(query)
//                  for data in result as! [NSManagedObject] {
//                      print(data.value(forKey: "dataName") as? String)
//                      print(data.value(forKey: "dataPrice") as? String)
//                    print(data.value(forKey: "dataQuantity") as? Int32)
//                        print(data.value(forKey: "dataDescription") as? String)
//
//        } catch {
//
//                  print("Failed")
//        }
//        lbl_last_name.text = "something";
        

        // Do any additional setup after loading the view.
    }
    var quantity: Int = 1 {
            didSet {
                // Update the quantity label
                foodQuantity.text = "\(quantity)"
                
                // Update the price label based on the new quantity
                let unitPrice = Double(priceVal.dropFirst()) // Convert priceVal to a Double by removing the "$" symbol
                let totalPrice = unitPrice! * Double(quantity)
                foodPrice.text = String(format: "$%.2f", totalPrice)
            }
        }
    @IBAction func decQuantity(_ sender: UIButton) {
        if quantity > 1 {
                   quantity -= 1
               }
    }
    
    
    @IBAction func incQuantity(_ sender: UIButton) {
        quantity += 1
    }
    
    @IBAction func addToCart(_ sender: Any) {
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "CartViewController") as! CartViewController
        
        secondVC.dataName = foodName.text
        secondVC.dataDescription = foodDesciption.text
        secondVC.dataQuantity = quantity
        secondVC.dataPrice = foodPrice.text
        
        
        
        
       // navigating to SecondViewController
        self.navigationController?.pushViewController(secondVC, animated: true)
        
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
