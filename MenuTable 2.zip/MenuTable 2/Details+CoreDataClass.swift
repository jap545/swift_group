//
//  Details+CoreDataClass.swift
//  MenuTable
//
//  Created by Ravneesh Singh Matharu on 2023-07-29.
//
//

import Foundation
import CoreData


public class Details: NSManagedObject {

}
