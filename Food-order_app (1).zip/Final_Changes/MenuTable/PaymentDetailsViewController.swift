//
//  PaymentDetailsViewController.swift
//  MenuTable
//
//  Created by user243826 on 8/11/23.
//

import UIKit

class PaymentDetailsViewController: UIViewController {

   
    @IBOutlet weak var payImage: UIImageView!
    
    @IBOutlet weak var selectedCard: UITextField!
    
    @IBOutlet weak var cardNumber: UITextField!
    
    
    @IBOutlet weak var expirationField: UITextField!
    @IBOutlet weak var cvvNumber: UITextField!
    @IBOutlet weak var cardHolder: UITextField!
    
    
    var name : String!
    var image: UIImage!
    override func viewDidLoad() {
        super.viewDidLoad()
        payImage.image = image
        selectedCard.text = name

        // Do any additional setup after loading the view.
    }
    

    @IBAction func makePayBtn(_ sender: UIButton)
    {
        
        if let number = cardNumber.text, Int(number) == nil || number.count > 16 || number.count != 16
        {
                let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
                
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
         }
        
        if let expiry = expirationField.text, expiry.isEmpty
        {
         
            let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
         
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
         
            self.present(alertController, animated: true, completion: nil)
        }
        
        if let cvv = cvvNumber.text, Int(cvv) == nil || cvv.count > 3 || cvv.count != 3
        {
            let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
         
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
         
            self.present(alertController, animated: true, completion: nil)
        }
       
        if let owner = cardHolder.text, owner.isEmpty
        {
         
            let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
         
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
         
            self.present(alertController, animated: true, completion: nil)
        }

         else
        {
             
             let greetingsVC:GreetingsViewController = self.storyboard?.instantiateViewController(withIdentifier: "GreetingsViewController") as! GreetingsViewController
             self.navigationController?.pushViewController(greetingsVC, animated: true)
         }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
