//
//  SignUpViewController.swift
//  MenuTable
//
//  Created by user243826 on 7/30/23.
//

import UIKit

class SignUpViewController: UIViewController
{
    
    @IBOutlet weak var txtName: UITextField!

    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSignUp(_ sender: Any)
    {
        if let name = txtName.text, name.isEmpty
        {
            let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
                    
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    
            self.present(alertController, animated: true, completion: nil)
        }
        
        if txtPhone.text!.count != 10 || Int(txtPhone.text!) == nil
        {
            let alertController = UIAlertController(title: "Invalid Information", message: "Please provide valid information.", preferredStyle: .alert)
                    
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    
            self.present(alertController, animated: true, completion: nil)

        }
        if let email = txtEmail.text, email.isEmpty ||    !email.hasSuffix("@gmail.com")
            
        {
            let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
        
        //validating password using a regex
       if let password = txtPassword.text, password.isEmpty || password.range(of: "^[A-Za-z0-9._!%+-]+$", options: .regularExpression) == nil
    
        {
            let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
            
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }


        else
        {
            let tableVC = self.storyboard?.instantiateViewController(withIdentifier: "TableViewController")
            self.navigationController?.pushViewController(tableVC!, animated: true)
        }
        
        
    }
   
    
    @IBAction func btnSignIn(_ sender: Any)
    {
        let tableVC:SignInViewController = self.storyboard?.instantiateViewController(withIdentifier: "SignInViewController") as! SignInViewController
        
        
        
        self.navigationController?.pushViewController(tableVC, animated: true)
   
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
