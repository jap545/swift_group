//
//  SignInViewController.swift
//  MenuTable
//
//  Created by user243826 on 7/31/23.
//

import UIKit

class SignInViewController: UIViewController
{

    
    @IBOutlet weak var txtEmailid: UITextField!
    
    @IBOutlet weak var txtLoginPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSignIn(_ sender: Any)
    {
       if let email = txtEmailid.text, email.isEmpty || !email.hasSuffix("@gmail.com")
        {
    
           let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
            
           alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
           self.present(alertController, animated: true, completion: nil)
        }
        if let password = txtLoginPassword.text, password.isEmpty || password.range(of: "^[A-Za-z0-9._!%+-]+$", options: .regularExpression) == nil                  {
                    let alertController = UIAlertController(title: "Invalid Information", message: "Please fill all the information in the fields.", preferredStyle: .alert)
                     
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
             
            self.present(alertController, animated: true, completion: nil)
         }

        else
        {
    
            let tableVC:TableViewController = self.storyboard?.instantiateViewController(withIdentifier: "TableViewController") as! TableViewController
                           
            
            self.navigationController?.pushViewController(tableVC, animated: true)
        }
        
      
   

    }
    
    @IBAction func btnGoToSignUp(_ sender: Any)
    {
        let signupVC:SignUpViewController = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
               
                
        self.navigationController?.pushViewController(signupVC, animated: true)
   

    }
    /*
     
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
