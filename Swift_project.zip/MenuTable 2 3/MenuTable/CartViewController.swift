//
//  CartViewController.swift
//  MenuTable
//
//  Created by Ravneesh Singh Matharu on 2023-07-29.
//

import UIKit
import CoreData

class CartViewController: UIViewController, UIApplicationDelegate{
    
    
@IBOutlet weak var foodItem: UILabel!
@IBOutlet weak var itemDescription: UILabel!
@IBOutlet weak var itemQuantity: UILabel!
@IBOutlet weak var itemPrice: UILabel!
    
    
    var dataName : String?
    var dataDescription : String?
    var dataQuantity : Int?
    var dataPrice : String?

    override func viewDidLoad() {
        super.viewDidLoad()
        foodItem.text = dataName
        itemDescription.text = dataDescription
        itemQuantity.text = String(Int(dataQuantity!))
        itemPrice.text = dataPrice

        // Do any additional setup after loading the view.
    }
    

    @IBAction func deleteButt(_ sender: UIButton) {
//let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let alertController = UIAlertController(title: "Delete Item", message: "Do you really want to delete this?", preferredStyle: .alert)
               
               // Add "Yes" action
               alertController.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action) in
                   self.deleteItems()
               }))
               
               // Add "No" action
               alertController.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
               
               // Present the alert controller
               self.present(alertController, animated: true, completion: nil)
           }
    private func deleteItems() {
           let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
       
           do {
               try Details.deleteAll(in: context)
           } catch {
               print("Unable to delete items in context")
           }
       }
        
    
    
    
    
    @IBAction func onSave(_ sender: UIButton) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

        
        
        
        
       let itemDetails = Details(context: context)
        
        do {
            
            print("result: ", try Details.fetchAll(in: context));
        } catch let error as NSError {
          print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        itemDetails.dataName = foodItem.text!
        itemDetails.dataDescription = itemDescription.text!
        itemDetails.dataQuantity = Int16(itemQuantity.text!)!
        itemDetails.dataPrice = itemPrice.text!
        
        print("dataName", foodItem.text!)
        print("dataDescription", itemDescription.text!)
        print("dataQuantity", Int16(itemQuantity.text!)!)
        print("dataPrice", itemPrice.text!)
        // Saving the above data to database
        do {
            try context.save()
        } catch {
            print("Error saving the movie record", error)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
