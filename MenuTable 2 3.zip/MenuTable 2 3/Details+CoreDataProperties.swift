//
//  Details+CoreDataProperties.swift
//  MenuTable
//
//  Created by Ravneesh Singh Matharu on 2023-07-29.
//
//

import Foundation
import CoreData


extension Details {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Details> {
        return NSFetchRequest<Details>(entityName: "Details")
    }

    @NSManaged public var dataName: String?
    @NSManaged public var dataDescription: String?
    @NSManaged public var dataQuantity: Int16
    @NSManaged public var dataPrice: String?

}

extension Details : Identifiable {

}
