//
//  TableViewController.swift
//  MenuTable
//
//  Created by Ravneesh Singh Matharu on 2023-07-29.
//

import UIKit

class TableViewController: UITableViewController {
    
    let foodList = ["burger and fries", "mini burger, fries and drink", "burger, drink and 2pc oinion rings", "2pc Sugar pies"]
    let price = ["$4.00", "$3.85", "$2.99", "$1.77"]
    let images = ["burger_fries", "mini_burger", "burger_rings","sugar_pie"]
    let desc = ["Chicken Burger with extra myonese and medium amount of fries \nCal-1083 calories", "Mini Chicken Burger with medium fries and medium soft drink \nCal-1560 calories" , "Veg Burger with msdium soft drink and 2 pc of crispy onion rings /nCal-1500 calories", "2 pc of crispy coated with chocolate inside it /nCal-1800 calories"]
    let quantity = [1,1,1,1]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

            return foodList.count
        }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        if let tempCell = tableView.dequeueReusableCell(withIdentifier: "cell") {
            print("food list text\( foodList[indexPath.row])")
            tempCell.textLabel?.text = foodList[indexPath.row]
            tempCell.detailTextLabel?.text = price[indexPath.row]
            tempCell.imageView?.image = UIImage(named: images[indexPath.row])
            return tempCell
        }else{
          
            return UITableViewCell()
        }
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC:FoodDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "FoodDetailsViewController") as! FoodDetailsViewController
       // assign the values to the local variable declared in ProductDetailViewController Class
        detailVC.name = foodList[indexPath.row]
        detailVC.priceVal = price[indexPath.row]
        detailVC.image = UIImage(named: images[indexPath.row])!
        detailVC.foodDesc = desc[indexPath.row]
        detailVC.foodQty = String(Int(quantity[indexPath.row]))
        // make it navigate to ProductDetailViewController
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

        // #warning Incomplete implementation, return the number of rows
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


